#pragma once

struct lua_State;
void flashBindToLua(lua_State* L);
