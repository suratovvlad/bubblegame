#pragma once
#include "fquery_ui.h"

namespace fquery{
	namespace ui{
		FQuerySelector& pressable(FQuerySelector& selector);
	}
}