#pragma once

#include "fquery_ui.h"

namespace fquery{
	namespace ui{
		

		FQuerySelector& radio(FQuerySelector& selector, int selected = 0);
	}
}