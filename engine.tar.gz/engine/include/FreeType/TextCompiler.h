#pragma once

class ITextElement;

//-----------------------------------------------------------------------------
namespace freetype
{
ITextElement* compileText(const std::string& _text);
};
