#ifndef PLAYRIX_GUI_H_
#define PLAYRIX_GUI_H_

#include "GUI/Cursor.h"
#include "GUI/Widget.h"

#endif
