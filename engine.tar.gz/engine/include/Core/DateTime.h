#ifndef _DATETIME_H_
#define _DATETIME_H_

#ifndef _WIN32

/*typedef struct _SYSTEMTIME {
	WORD wYear;
	WORD wMonth;
	WORD wDay;
	WORD wHour;
	WORD wMinute;
	WORD wSecond;
} SYSTEMTIME;

void GetLocalTime(SYSTEMTIME *pst);*/

#endif

#endif