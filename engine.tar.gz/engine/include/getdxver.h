#ifndef _GETDXVER_H_
#define _GETDXVER_H_

// достаточная ли версия DirectX установлена для текущей сборки движка
bool CheckDXVersion();

#endif //_GETDXVER_H